function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  //for loops take three arguements 1) where to start 2) where to end 30 how much to increment by
  for(i = 0; i < 20; i++){
    fill(i*15, 255, 0, 100)
    ellipse(i*20, i*20, i*3)
    
  }
}

